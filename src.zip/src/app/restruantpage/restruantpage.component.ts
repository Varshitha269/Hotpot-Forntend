import { Component } from '@angular/core';

@Component({
  selector: 'app-restruantpage',
  standalone: true,
  imports: [],
  templateUrl: './restruantpage.component.html',
  styleUrl: './restruantpage.component.css'
})
export class RestruantpageComponent {

}
