import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RestruantpageComponent } from '../restruantpage/restruantpage.component';

@Component({
  selector: 'app-restaurantcards',
  standalone: true,
  imports: [CommonModule,FormsModule,RestruantpageComponent],
  templateUrl: './restaurantcards.component.html',
  styleUrl: './restaurantcards.component.css'
})
export class RestaurantcardsComponent {
  categories = [
    { name: 'Rolls', image: 'images/rolls.jpg' },
    { name: 'Cakes', image: 'images/cakes.jpg' },
    { name: 'Momos', image: 'images/momos.jpg' },
    { name: 'Noodles', image: 'images/noodels.jpg' },
    { name: 'South Indian', image: 'images/southindian.jpg' },
    { name: 'Shake', image: 'images/shakes.jpg' },
    { name: 'Biriyani', image: 'images/biriyani.jpg' },
    { name: 'Idli', image: 'images/idli.jpg' },
    { name: 'Dosa', image: 'images/dosa.jpg' },
    { name: 'South Indian', image: 'images/pizza.jpg' },
    { name: 'South Indian', image: 'images/burger.jpg' },
    { name: 'icecream', image: 'images/icecream.jpg' },
    { name: 'Pastry', image: 'images/pastry.jpg' }
  ];

 

  // Popular restaurants data
  restaurants = [
    { name: 'Restaurant 1', image: 'images/southindian.jpg', price: 5.00 },
    { name: 'Restaurant 2', image: 'images/pastry.jpg', price: 6.00 },
    { name: 'Restaurant 3', image: 'images/momos.jpg', price: 7.00 },
    { name: 'Restaurant 4', image: 'images/shakes.jpg', price: 8.00 },
    { name: 'Restaurant 5', image: 'images/noodels.jpg', price: 5.50 },
    { name: 'Restaurant 6', image: 'images/cakes.jpg', price: 6.50 },
    { name: 'Restaurant 7', image: 'images/rolls.jpg', price: 7.50 },
    { name: 'Restaurant 8', image: 'images/idli.jpg', price: 8.50 },
    { name: 'Restaurant 9', image: 'images/biriyani.jpg', price: 9.00 },
    { name: 'Restaurant 10', image: 'images/dosa.jpg', price: 10.00 },
    { name: 'Restaurant 11', image: 'images/icecream.jpg', price: 11.50 },
    { name: 'Restaurant 12', image: 'images/pizza.jpg', price: 15.50 },
    { name: 'Restaurant 13', image: 'images/burger.jpg', price: 16.50 }
  ];

}
