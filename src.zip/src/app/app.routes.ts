import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RestaurantcardsComponent } from './restaurantcards/restaurantcards.component';
import { RestruantpageComponent } from './restruantpage/restruantpage.component';
import { TestComponent } from './test/test.component';

export const routes: Routes = [

    {
        path:'app-header',
        component:HeaderComponent
    },
    {
        path:'app-test',
        component:TestComponent

    },
    {
        path:'app-footer',
        component:FooterComponent

    },
    {
        path:'',
        component:RestaurantcardsComponent
    },
    {
        path:'app-restruantpage',
        component:RestruantpageComponent
    }
];
